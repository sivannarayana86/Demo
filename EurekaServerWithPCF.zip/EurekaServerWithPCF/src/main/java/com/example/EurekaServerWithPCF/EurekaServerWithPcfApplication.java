package com.example.EurekaServerWithPCF;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaServerWithPcfApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerWithPcfApplication.class, args);
	}
}
